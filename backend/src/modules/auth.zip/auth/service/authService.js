import { ConflictError, InternalServerError } from "../../../../shared/errors/app-error.js";
import AuthRepository from "../repository/AuthRepository.js";

class AuthService {
    constructor() {
        this.repo = new AuthRepository()
    }
    async register(userData) {
        const existingUser = await this.repo.findUserByEmail(userData.email);

        if (existingUser) {
            throw new ConflictError("Email already exists.");
        }

        const user = await this.repo.createUser(userData);

        if (!user) {
            throw new InternalServerError("Failed to create user.");
        }

        // TODO: send email after creation, background work
        return user;
    }

    async login(userData) {
        const type = userData.type;
        const strategy = AuthStrategyFactory.getStrategy(type);
        const user = await strategy.execute(userData);
        const jti = tokenService.generateJti();
        const accessToken = tokenService.generateAccessToken(user.id, jti);
        const refreshToken = tokenService.generateRefreshToken(user.id, jti);
        
        const refreshTokenHash =  tokenService.hashToken(refreshToken);

        const session = await this.repo.createSession({
            userId: user.id,
            jti,
            refreshTokenHash,
            expiresAt,
        });

        // TODO : cache sessionData to redis 

        // set token here , or in controller?
        return { user, accessToken, refreshToken, session }

    }
}

export default AuthService;