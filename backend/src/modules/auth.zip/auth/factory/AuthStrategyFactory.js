class AuthStrategyFactory {
    static getStrategy(type) {
        switch (type) {
            case "credentials":
                return new CredentialsStrategy();

            case "google":
                return new GoogleStrategy();

            default:
                throw new Error("Unsupported authentication strategy");
        }
    }
}