import z from "zod";

export const credentialLoginSchema = z.object({
    email: z.email("Invalid email format").trim(),
    password: z.string().trim().min(6, "Password must be at least 6 characters long"),
})
